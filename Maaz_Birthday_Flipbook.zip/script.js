const pages = [{'title': 'Cover', 'content': '🐧 Happy 17th Birthday, Maaz!<br>WRITE_YOUR_COVER_MESSAGE'}, {'title': 'Page 1', 'content': 'WRITE_YOUR_MESSAGE_HERE'}, {'title': 'Page 2', 'content': 'ADD_FAVORITE_MEMORY_HERE'}, {'title': 'Page 3', 'content': 'THINGS_YOU_ADMIRE_ABOUT_HIM'}, {'title': 'Page 4', 'content': 'ADD_PHOTO_OR_SCREENSHOT_DESCRIPTION'}, {'title': 'Page 5', 'content': 'FUNNY_INSIDE_JOKES'}, {'title': 'Page 6', 'content': 'BIRTHDAY_WISHES_FOR_THIS_YEAR'}, {'title': 'Page 7', 'content': 'YOUR_FAVORITE_THINGS_ABOUT_HIM'}, {'title': 'Page 8', 'content': 'PLACE_FOR_A_SPECIAL_NOTE'}, {'title': 'Page 9', 'content': 'ANOTHER_MEMORY'}, {'title': 'Page 10', 'content': 'THINGS_YOU_HOPE_HE_ACHIEVES'}, {'title': 'Page 11', 'content': 'ADD_A_CUTE_PENGUIN_MESSAGE'}, {'title': 'Page 12', 'content': 'MORE_PHOTOS_OR_CAPTIONS'}, {'title': 'Page 13', 'content': 'A_NOTE_OF_ENCOURAGEMENT'}, {'title': 'Page 14', 'content': 'YOUR_FAVORITE_CHAT_MEMORY'}, {'title': 'Page 15', 'content': 'A_FINAL_BIRTHDAY_WISH'}, {'title': 'Page 16', 'content': 'THANK_YOU_FOR_BEING_YOU'}, {'title': 'Page 17', 'content': 'Tap the surprise below 🎂'}];

let current=0;
const title=document.getElementById("title");
const content=document.getElementById("content");

function render(){
    title.innerHTML=pages[current].title;
    content.innerHTML=pages[current].content;
    document.getElementById("surprise").classList.toggle(
        "hidden", current !== pages.length-1
    );
}
function nextPage(){
    if(current<pages.length-1){current++;render();}
}
function prevPage(){
    if(current>0){current--;render();}
}
function confetti(){
    alert("🎉 Happy Birthday, Maaz! Replace this with your own special message.");
}
render();
